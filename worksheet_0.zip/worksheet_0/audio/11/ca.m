function new_signal = ca(signal, W)
  signal(signal < 0) = 0
  signal = [signal(:, 1) signak]
end
